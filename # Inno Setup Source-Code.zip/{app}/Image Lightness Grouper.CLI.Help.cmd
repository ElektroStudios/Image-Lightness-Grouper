@ECHO OFF

"%~dp0Image Lightness Grouper.CLI.exe" /?

PAUSE